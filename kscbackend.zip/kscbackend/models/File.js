// models/File.js
import mongoose from "mongoose";

const fileSchema = new mongoose.Schema(
  {
    originalName: { type: String, required: true },
    filename: { type: String, required: true },
    url: { type: String, required: true },

    // metadata from student submission form
    level: { type: String, default: "" },
    subject: { type: String, default: "" },
    notes: { type: String, default: "" },
    studentEmail: { type: String, default: "" },
    studentRole: { type: String, default: "" },
    examId: { type: mongoose.Schema.Types.ObjectId, ref: "Exam" },
    sessionId: { type: mongoose.Schema.Types.ObjectId, ref: "ExamSession" },
    questionId: { type: mongoose.Schema.Types.ObjectId, ref: "ExamQuestion" },
      // Review status for submissions
      status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" },
      reviewerNotes: { type: String, default: "" },
      reviewedBy: { type: String, default: "" },
  },
  { timestamps: { createdAt: "uploadedAt", updatedAt: "updatedAt" } }
);

export default mongoose.model("File", fileSchema);
